document.addEventListener('DOMContentLoaded', function() {
  const apiResults = document.getElementById('apiResults');
  const testAddSchoolBtn = document.getElementById('testAddSchool');
  const testListSchoolsBtn = document.getElementById('testListSchools');
  
  /**
   * Display API results in the results container
   * @param {Object} data - The response data to display
   * @param {boolean} isError - Whether this is an error response
   */
  function displayResult(data, isError = false) {
    const resultElement = document.createElement('div');
    resultElement.classList.add('mb-3', 'p-2', 'rounded');
    
    if (isError) {
      resultElement.classList.add('error-response');
    } else {
      resultElement.classList.add('success-response');
    }
    
    const timestamp = new Date().toLocaleTimeString();
    const heading = document.createElement('h6');
    heading.innerHTML = `${timestamp} - ${isError ? 'Error' : 'Success'}`;
    resultElement.appendChild(heading);
    
    const content = document.createElement('pre');
    content.textContent = JSON.stringify(data, null, 2);
    resultElement.appendChild(content);
    
    // Add to results container
    apiResults.innerHTML = '';
    apiResults.appendChild(resultElement);
  }
  
  /**
   * Test the Add School API
   */
  testAddSchoolBtn.addEventListener('click', async function() {
    try {
      // Generate random coordinates near San Francisco
      const lat = 37.7749 + (Math.random() - 0.5) * 0.1;
      const lng = -122.4194 + (Math.random() - 0.5) * 0.1;
      
      // Create a sample school
      const schoolData = {
        name: `School ${Math.floor(Math.random() * 1000)}`,
        address: `${Math.floor(Math.random() * 1000)} Education St, San Francisco, CA`,
        latitude: parseFloat(lat.toFixed(6)),
        longitude: parseFloat(lng.toFixed(6))
      };
      
      // Send request to add school
      const response = await fetch('/addSchool', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(schoolData)
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw result;
      }
      
      displayResult(result);
    } catch (error) {
      displayResult(error, true);
    }
  });
  
  /**
   * Test the List Schools API
   */
  testListSchoolsBtn.addEventListener('click', async function() {
    try {
      // Generate random coordinates near San Francisco
      const lat = 37.7749 + (Math.random() - 0.5) * 0.1;
      const lng = -122.4194 + (Math.random() - 0.5) * 0.1;
      
      // Send request to list schools
      const response = await fetch(`/listSchools?latitude=${lat}&longitude=${lng}`);
      const result = await response.json();
      
      if (!response.ok) {
        throw result;
      }
      
      displayResult(result);
    } catch (error) {
      displayResult(error, true);
    }
  });
});
