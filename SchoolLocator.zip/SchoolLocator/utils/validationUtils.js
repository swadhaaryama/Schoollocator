const { check, query } = require('express-validator');

/**
 * Validation middleware for the add school endpoint
 */
exports.validateAddSchool = [
  // Validate name
  check('name')
    .trim()
    .notEmpty().withMessage('School name is required')
    .isLength({ min: 2, max: 255 }).withMessage('School name must be between 2 and 255 characters'),
  
  // Validate address
  check('address')
    .trim()
    .notEmpty().withMessage('School address is required')
    .isLength({ min: 5, max: 255 }).withMessage('School address must be between 5 and 255 characters'),
  
  // Validate latitude
  check('latitude')
    .notEmpty().withMessage('Latitude is required')
    .isFloat({ min: -90, max: 90 }).withMessage('Latitude must be a valid number between -90 and 90'),
  
  // Validate longitude
  check('longitude')
    .notEmpty().withMessage('Longitude is required')
    .isFloat({ min: -180, max: 180 }).withMessage('Longitude must be a valid number between -180 and 180')
];

/**
 * Validation middleware for the list schools endpoint
 */
exports.validateListSchools = [
  // Validate latitude
  query('latitude')
    .notEmpty().withMessage('Latitude is required')
    .isFloat({ min: -90, max: 90 }).withMessage('Latitude must be a valid number between -90 and 90'),
  
  // Validate longitude
  query('longitude')
    .notEmpty().withMessage('Longitude is required')
    .isFloat({ min: -180, max: 180 }).withMessage('Longitude must be a valid number between -180 and 180')
];
