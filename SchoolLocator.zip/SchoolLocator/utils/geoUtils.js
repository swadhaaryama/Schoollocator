/**
 * Utility functions for geographical calculations
 */

/**
 * Calculate the distance between two geographic coordinates using the Haversine formula
 * @param {number} lat1 - Latitude of first point (in degrees)
 * @param {number} lon1 - Longitude of first point (in degrees)
 * @param {number} lat2 - Latitude of second point (in degrees)
 * @param {number} lon2 - Longitude of second point (in degrees)
 * @returns {number} - Distance in kilometers
 */
exports.calculateDistance = (lat1, lon1, lat2, lon2) => {
  // Convert degrees to radians
  const toRadians = (degrees) => degrees * Math.PI / 180;
  
  // Earth's radius in kilometers
  const earthRadius = 6371;
  
  // Convert latitude and longitude to radians
  const latRad1 = toRadians(lat1);
  const lonRad1 = toRadians(lon1);
  const latRad2 = toRadians(lat2);
  const lonRad2 = toRadians(lon2);
  
  // Calculate differences
  const latDiff = latRad2 - latRad1;
  const lonDiff = lonRad2 - lonRad1;
  
  // Apply Haversine formula
  const a = Math.sin(latDiff / 2) ** 2 + 
           Math.cos(latRad1) * Math.cos(latRad2) * 
           Math.sin(lonDiff / 2) ** 2;
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  
  // Calculate distance
  const distance = earthRadius * c;
  
  return distance;
};

/**
 * Validate if coordinates are valid geographical coordinates
 * @param {number} latitude - Latitude to validate
 * @param {number} longitude - Longitude to validate
 * @returns {boolean} - Whether coordinates are valid
 */
exports.validateCoordinates = (latitude, longitude) => {
  // Check if latitude is a number between -90 and 90
  const isValidLatitude = !isNaN(latitude) && 
                          parseFloat(latitude) >= -90 && 
                          parseFloat(latitude) <= 90;
  
  // Check if longitude is a number between -180 and 180
  const isValidLongitude = !isNaN(longitude) && 
                           parseFloat(longitude) >= -180 && 
                           parseFloat(longitude) <= 180;
  
  return isValidLatitude && isValidLongitude;
};
