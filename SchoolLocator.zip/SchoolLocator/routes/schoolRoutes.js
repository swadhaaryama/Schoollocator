const express = require('express');
const router = express.Router();
const schoolController = require('../controllers/schoolController');
const { validateAddSchool, validateListSchools } = require('../utils/validationUtils');

// Route to add a new school
router.post('/addSchool', validateAddSchool, schoolController.addSchool);

// Route to list schools sorted by proximity
router.get('/listSchools', validateListSchools, schoolController.listSchools);

// Home route for documentation
router.get('/', (req, res) => {
  res.sendFile('index.html', { root: './public' });
});

module.exports = router;
