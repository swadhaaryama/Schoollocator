const { Pool } = require('pg');
require('dotenv').config();

// Create pool using environment DATABASE_URL
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false
  }
});

// Create table if not exists
const initializeDatabase = async () => {
  try {
    const client = await pool.connect();
    
    // Create schools table if it doesn't exist
    await client.query(`
      CREATE TABLE IF NOT EXISTS schools (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        address VARCHAR(255) NOT NULL,
        latitude FLOAT NOT NULL,
        longitude FLOAT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    console.log('Database table initialized successfully');
    client.release();
  } catch (error) {
    console.error('Error initializing database:', error);
  }
};

// Initialize the database
initializeDatabase();

// Function to get a client from the pool
const getConnection = async (callback) => {
  const client = await pool.connect();
  callback(null, client);
};

// Add getConnection method to maintain compatibility with existing code
pool.getConnection = getConnection;

module.exports = pool;
