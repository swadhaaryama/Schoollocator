import os
import subprocess
from flask import Flask, send_from_directory

app = Flask(__name__)

# Start Node.js as a separate process
subprocess.Popen(['node', 'server.js'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

@app.route('/')
def index():
    # Simply serve the static index.html file
    return send_from_directory('public', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    # Serve any other static files requested
    return send_from_directory('public', path)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)