const db = require('../config/database');

/**
 * Model for school-related database operations
 */
const schoolModel = {
  /**
   * Add a new school to the database
   * @param {Object} school - School object with name, address, latitude, longitude
   * @returns {Promise} - PostgreSQL result object
   */
  addSchool: async (school) => {
    try {
      const client = await db.connect();
      const query = 'INSERT INTO schools (name, address, latitude, longitude) VALUES ($1, $2, $3, $4) RETURNING id, name, address, latitude, longitude';
      const values = [school.name, school.address, school.latitude, school.longitude];
      
      const result = await client.query(query, values);
      client.release();
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get all schools from the database
   * @returns {Promise<Array>} - Array of school objects
   */
  getAllSchools: async () => {
    try {
      const client = await db.connect();
      const query = 'SELECT id, name, address, latitude, longitude FROM schools';
      
      const result = await client.query(query);
      client.release();
      return result.rows;
    } catch (error) {
      throw error;
    }
  },

  /**
   * Get a school by ID
   * @param {number} id - School ID
   * @returns {Promise<Object>} - School object
   */
  getSchoolById: async (id) => {
    try {
      const client = await db.connect();
      const query = 'SELECT id, name, address, latitude, longitude FROM schools WHERE id = $1';
      
      const result = await client.query(query, [id]);
      client.release();
      
      if (result.rows.length === 0) {
        throw new Error('School not found');
      }
      
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  }
};

module.exports = schoolModel;
