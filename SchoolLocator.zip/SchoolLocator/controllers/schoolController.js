const schoolModel = require('../models/schoolModel');
const geoUtils = require('../utils/geoUtils');
const { validationResult } = require('express-validator');

/**
 * Add a new school to the database
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
exports.addSchool = async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    // Extract school details from request body
    const { name, address, latitude, longitude } = req.body;

    // Add school to database
    const result = await schoolModel.addSchool({
      name,
      address,
      latitude,
      longitude
    });

    // Return success response
    return res.status(201).json({
      success: true,
      message: 'School added successfully',
      data: result // PostgreSQL already returns the full object with id
    });
  } catch (error) {
    console.error('Error adding school:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to add school',
      error: error.message
    });
  }
};

/**
 * List all schools sorted by proximity to user location
 * @param {Object} req - Express request object
 * @param {Object} res - Express response object
 */
exports.listSchools = async (req, res) => {
  try {
    // Check for validation errors
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        success: false,
        errors: errors.array()
      });
    }

    // Extract user location from query parameters
    const { latitude, longitude } = req.query;
    const userLat = parseFloat(latitude);
    const userLng = parseFloat(longitude);

    // Get all schools from database
    const schools = await schoolModel.getAllSchools();

    // Calculate distance for each school and sort by proximity
    const schoolsWithDistance = schools.map(school => {
      const distance = geoUtils.calculateDistance(
        userLat, 
        userLng, 
        parseFloat(school.latitude), 
        parseFloat(school.longitude)
      );
      
      return {
        ...school,
        distance: parseFloat(distance.toFixed(2)) // Convert to number, rounded to 2 decimal places
      };
    });

    // Sort schools by distance (ascending)
    schoolsWithDistance.sort((a, b) => a.distance - b.distance);

    // Return sorted schools
    return res.status(200).json({
      success: true,
      message: 'Schools retrieved successfully',
      data: schoolsWithDistance
    });
  } catch (error) {
    console.error('Error listing schools:', error);
    return res.status(500).json({
      success: false,
      message: 'Failed to list schools',
      error: error.message
    });
  }
};
